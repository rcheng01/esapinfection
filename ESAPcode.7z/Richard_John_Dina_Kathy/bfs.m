function [v] = bfs(A,s) %This code is designed to be a very fast, decently accurate approximation of ICM using BFS.
seeds = zeros(length(A),1);
seeds(s) = 1;
iniTime = clock;
limit = 0.03;
while etime(clock, iniTime) < limit %What the past three lines do is make it escape the loop if over 0.03 s elapses.
    temp = seeds;
    comp = 1-(A.*seeds);               
    new_Infec = (1 - prod(comp)); %The previous two lines creates a vector of the probabilities that each node is infected.
    seeds = max([seeds new_Infec']')'; %This combines the new infected nodes with the previous seeds to create the new updated seeds.
end
v = [sum(seeds) s]; %Returns the sum of the probabilities of the seeds as well as the input. It returns s because this proved to be useful in better_than_outdegree.
end