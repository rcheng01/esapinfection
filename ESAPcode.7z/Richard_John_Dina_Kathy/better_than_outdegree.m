function seeds = better_than_outdegree(A,n) %This algorithm is meant to use a quick version of hill-climbing to produce a result better than outdegree. (Most of the time.)
seeds = zeros(length(A),1); 
infected = [];
O = sum(A,2); %lines 4-6 are the rankings produced by outdegree.
[B,I] = sort(O,'descend');
s = I(1:n);
for j = n:-1:n-2; %These nested for loops replace terms in the seeds with the n+k next best node according to outdegree, runs them through BFS, and sees if it is optimal to replace the node.
    for k = 0:3;
        s(j) = I(n + k);
        infected = [infected bfs(A,s')'];
    end
    M = infected(1,:) %This takes the maximum value from the hill-climbing.
    [m,i] = max(M) %This returns the index of the maximum.
    s = infected(2:end,i)
end
seeds = zeros(length(A),1);
seeds(s) = 1; %The final result is a vector that hopefully outperforms outdegree.
end